<?php
/**
 * Plugin Name: CleanWP Stealth
 * Plugin URI: https://www.sangamam.co.in/
 * Description: Reduce common WordPress fingerprints, protect selected public endpoints, and optionally use a custom login URL without modifying WordPress core.
 * Version: 1.1.0
 * Author: Sudeep S
 * Author URI: https://www.sudeep.co.in/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: cleanwp-stealth
 * Domain Path: /languages
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) exit;
final class CleanWP_Stealth {
 const VERSION='1.1.1'; const OPTION='cleanwp_stealth_options'; const SLUG='cleanwp-stealth'; const DEFAULT_LOGIN_SLUG='secure-login';
 public static function init(){
  add_action('init',[__CLASS__,'register_custom_login_rewrite']); add_action('template_redirect',[__CLASS__,'serve_custom_login'],0); add_action('template_redirect',[__CLASS__,'redirect_wp_login'],1);
  add_action('wp_head',[__CLASS__,'cleanup_head'],1); add_filter('the_generator','__return_empty_string'); add_filter('style_loader_src',[__CLASS__,'remove_asset_version'],9999); add_filter('script_loader_src',[__CLASS__,'remove_asset_version'],9999);
  add_filter('xmlrpc_enabled',[__CLASS__,'xmlrpc_enabled']); add_filter('rest_endpoints',[__CLASS__,'rest_endpoints']); add_filter('wp_sitemaps_enabled',[__CLASS__,'sitemaps_enabled']);
  add_filter('login_url',[__CLASS__,'filter_login_url'],10,3); add_filter('lostpassword_url',[__CLASS__,'filter_lostpassword_url'],10,2);
  add_action('admin_menu',[__CLASS__,'admin_menu']); add_action('admin_init',[__CLASS__,'register_settings']); add_action('admin_enqueue_scripts',[__CLASS__,'admin_assets']); add_filter('admin_footer_text',[__CLASS__,'admin_footer']); add_filter('plugin_action_links_'.plugin_basename(__FILE__),[__CLASS__,'plugin_action_links']); add_action('init',[__CLASS__,'maybe_block_xmlrpc_request'],0);
 }
 public static function defaults(){return ['remove_generator'=>1,'remove_asset_versions'=>1,'remove_discovery'=>1,'disable_xmlrpc'=>1,'block_user_rest'=>1,'hide_login'=>1,'login_slug'=>self::DEFAULT_LOGIN_SLUG,'redirect_wp_login'=>0,'hide_wp_sitemap'=>0];}
 public static function get_options(){return wp_parse_args((array)get_option(self::OPTION,[]),self::defaults());}
 public static function sanitize_options($input){$d=self::defaults();$o=[];foreach(['remove_generator','remove_asset_versions','remove_discovery','disable_xmlrpc','block_user_rest','hide_login','redirect_wp_login','hide_wp_sitemap'] as $k)$o[$k]=!empty($input[$k])?1:0;$slug=isset($input['login_slug'])?sanitize_title(wp_unslash($input['login_slug'])):self::DEFAULT_LOGIN_SLUG;$reserved=['wp-admin','wp-login','wp-signup','wp-register','admin','login','logout','xmlrpc','wp-json','wp-cron','feed'];if(!$slug||in_array($slug,$reserved,true))$slug=self::DEFAULT_LOGIN_SLUG;$o['login_slug']=$slug;return wp_parse_args($o,$d);}
 public static function is_custom_login_request(){ $o=self::get_options(); if(empty($o['hide_login']))return false; $p=trim((string)wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']??'/'),PHP_URL_PATH),'/');$hp=trim((string)wp_parse_url(home_url('/'),PHP_URL_PATH),'/');if($hp&&0===strpos($p,$hp.'/'))$p=substr($p,strlen($hp)+1);return $p===trim($o['login_slug'],'/'); }
 public static function register_custom_login_rewrite(){ $o=self::get_options(); if(empty($o['hide_login']))return; add_rewrite_tag('%cleanwp_login%','([01])'); add_rewrite_rule('^'.preg_quote(trim($o['login_slug'],'/'),'/').'/?$','index.php?cleanwp_login=1','top'); }
 public static function serve_custom_login(){ if(!self::is_custom_login_request())return; if(defined('WP_ADMIN')&&WP_ADMIN)return; global $pagenow;if('wp-login.php'===$pagenow)return;$file=ABSPATH.'wp-login.php';if(file_exists($file)){require $file;exit;} }
 public static function redirect_wp_login(){ $o=self::get_options();if(empty($o['hide_login'])||empty($o['redirect_wp_login']))return;$p=trim((string)wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']??'/'),PHP_URL_PATH),'/');$login=trim(wp_parse_url(site_url('wp-login.php'),PHP_URL_PATH),'/');if($p===$login){wp_safe_redirect(self::login_url(),302);exit;} }

public static function cleanwp_path(){
 $path=trim((string)wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']??'/'),PHP_URL_PATH),'/');
 $home=trim((string)wp_parse_url(home_url('/'),PHP_URL_PATH),'/');
 if($home && 0===strpos($path,$home.'/')) $path=substr($path,strlen($home)+1);
 return trim($path,'/');
}

public static function block_direct_wp_login(){
 $o=self::get_options(); if(empty($o['hide_login'])) return;
 if(self::is_custom_login_request()) return;
 $path=self::cleanwp_path();
 if('wp-login.php'===$path){ self::hard_404(); }
}

public static function block_public_wp_locations(){
 $o=self::get_options(); if(empty($o['hide_login'])) return;
 if(is_user_logged_in()) return;
 $path=self::cleanwp_path();
 if(self::is_custom_login_request()) return;
 // Stop WordPress shorthand canonical redirects such as /login, /admin and /dashboard.
 $blocked=array('login','login.php','admin','dashboard','wp-login.php');
 if(in_array($path,$blocked,true) || 0===strpos($path,'wp-admin')){
   // Preserve commonly used public admin-post/admin-ajax endpoints for compatibility.
   if('wp-admin/admin-ajax.php'===$path || 'wp-admin/admin-post.php'===$path) return;
   self::hard_404();
 }
}

private static function hard_404(){
 status_header(404); nocache_headers(); header('X-Robots-Tag: noindex, nofollow',true); exit;
}
 public static function login_url($redirect=''){ $o=self::get_options();$u=home_url('/'.trim($o['login_slug'],'/').'/');if($redirect)$u=add_query_arg('redirect_to',$redirect,$u);return $u; }
 public static function filter_login_url($url,$redirect='',$force_reauth=false){$o=self::get_options();if(empty($o['hide_login']))return $url;$u=self::login_url($redirect);if($force_reauth)$u=add_query_arg('reauth','1',$u);return $u;}
 public static function filter_lostpassword_url($url,$redirect){$o=self::get_options();if(empty($o['hide_login']))return $url;$a=['action'=>'lostpassword'];if($redirect)$a['redirect_to']=$redirect;return add_query_arg($a,self::login_url());}
 public static function cleanup_head(){if(!empty(self::get_options()['remove_discovery'])){remove_action('wp_head','rsd_link');remove_action('wp_head','wlwmanifest_link');remove_action('wp_head','wp_shortlink_wp_head');remove_action('wp_head','rest_output_link_wp_head');}}
 public static function remove_asset_version($src){if(empty(self::get_options()['remove_asset_versions'])||empty($src))return $src;return remove_query_arg('ver',$src);}
 public static function xmlrpc_enabled($enabled){return !empty(self::get_options()['disable_xmlrpc'])?false:$enabled;}
 public static function maybe_block_xmlrpc_request(){if(empty(self::get_options()['disable_xmlrpc']))return;if(defined('XMLRPC_REQUEST')&&XMLRPC_REQUEST){status_header(403);wp_die(esc_html__('XML-RPC is disabled by CleanWP Stealth.','cleanwp-stealth'),esc_html__('XML-RPC Disabled','cleanwp-stealth'),['response'=>403]);}}
 public static function rest_endpoints($e){if(empty(self::get_options()['block_user_rest']))return $e;unset($e['/wp/v2/users'],$e['/wp/v2/users/(?P<id>[\d]+)']);return $e;}
 public static function sitemaps_enabled($enabled){return !empty(self::get_options()['hide_wp_sitemap'])?false:$enabled;}
 public static function admin_menu(){add_options_page(__('CleanWP Stealth','cleanwp-stealth'),__('CleanWP Stealth','cleanwp-stealth'),'manage_options',self::SLUG,[__CLASS__,'settings_page']);}
 public static function register_settings(){register_setting('cleanwp_stealth_group',self::OPTION,['type'=>'array','sanitize_callback'=>[__CLASS__,'sanitize_options'],'default'=>self::defaults()]);}
 public static function admin_assets($hook){if('settings_page_'.self::SLUG!==$hook)return;wp_enqueue_style(self::SLUG,plugins_url('assets/css/admin.css',__FILE__),[],self::VERSION);}
 public static function plugin_action_links($links){array_unshift($links,'<a href="'.esc_url(admin_url('options-general.php?page='.self::SLUG)).'">'.esc_html__('Settings','cleanwp-stealth').'</a>');return $links;}
 public static function admin_footer($text){$screen=function_exists('get_current_screen')?get_current_screen():null;if($screen&&self::SLUG===$screen->id)return esc_html__('CleanWP Stealth by Sudeep S · Sangamam Communications Pvt Ltd','cleanwp-stealth');return $text;}
 public static function status(){ $o=self::get_options();return [
  [__('WordPress generator','cleanwp-stealth'),!empty($o['remove_generator']),__('Removes the standard generator fingerprint.','cleanwp-stealth')],
  [__('Asset version fingerprints','cleanwp-stealth'),!empty($o['remove_asset_versions']),__('Removes common version query strings from enqueued assets.','cleanwp-stealth')],
  [__('Discovery tags','cleanwp-stealth'),!empty($o['remove_discovery']),__('Removes selected RSD, WLW, shortlink and REST discovery tags.','cleanwp-stealth')],
  [__('XML-RPC','cleanwp-stealth'),!empty($o['disable_xmlrpc']),__('Blocks XML-RPC when enabled.','cleanwp-stealth')],
  [__('Public user REST endpoints','cleanwp-stealth'),!empty($o['block_user_rest']),__('Removes the public users endpoint from the REST index.','cleanwp-stealth')],
  [__('Custom login URL','cleanwp-stealth'),!empty($o['hide_login']),!empty($o['hide_login'])?sprintf(__('Active at %s','cleanwp-stealth'),self::login_url()):__('WordPress login URL remains unchanged.','cleanwp-stealth')],
 ]; }
 public static function settings_page(){if(!current_user_can('manage_options'))return;$o=self::get_options();$status=self::status();$settings=[
  'remove_generator'=>[__('Remove WordPress generator','cleanwp-stealth'),__('Hides the standard WordPress generator information from public page source.','cleanwp-stealth')],
  'remove_asset_versions'=>[__('Remove asset version strings','cleanwp-stealth'),__('Removes common ?ver= fingerprints from CSS and JavaScript URLs enqueued by WordPress.','cleanwp-stealth')],
  'remove_discovery'=>[__('Remove discovery tags','cleanwp-stealth'),__('Removes selected RSD, WLW manifest, shortlink and REST discovery tags.','cleanwp-stealth')],
  'disable_xmlrpc'=>[__('Disable XML-RPC','cleanwp-stealth'),__('Recommended when your site does not rely on XML-RPC-based integrations.','cleanwp-stealth')],
  'block_user_rest'=>[__('Protect public user REST endpoints','cleanwp-stealth'),__('Removes public WordPress users endpoints while leaving the REST API available for normal use.','cleanwp-stealth')],
  'hide_wp_sitemap'=>[__('Disable WordPress sitemap','cleanwp-stealth'),__('Only enable this if another sitemap solution is active.','cleanwp-stealth')],
 ]; ?>
 <div class="wrap cleanwp-wrap"><div class="cleanwp-hero"><div><div class="cleanwp-brand-row"><div class="cleanwp-mark">C</div><div><p class="cleanwp-kicker">SANGAMAM COMMUNICATIONS</p><h1>CleanWP Stealth</h1></div></div><p class="cleanwp-lead"><?php esc_html_e('A clean, controlled and professional public-facing WordPress footprint.','cleanwp-stealth'); ?></p><p class="cleanwp-meta"><?php printf(esc_html__('Free Edition · Version %s','cleanwp-stealth'),esc_html(self::VERSION)); ?></p></div><div class="cleanwp-author"><span><?php esc_html_e('Developed by','cleanwp-stealth'); ?></span><strong>Sudeep S</strong><a href="https://www.sudeep.co.in/" target="_blank" rel="noopener noreferrer">www.sudeep.co.in</a><a href="https://www.sangamam.co.in/" target="_blank" rel="noopener noreferrer">www.sangamam.co.in</a></div></div>
 <div class="cleanwp-grid"><div class="cleanwp-main"><div class="cleanwp-card"><div class="cleanwp-card-head"><div><h2><?php esc_html_e('Protection Overview','cleanwp-stealth'); ?></h2><p><?php esc_html_e('Your current CleanWP configuration at a glance.','cleanwp-stealth'); ?></p></div><div class="cleanwp-status-pill"><span class="cleanwp-dot"></span><?php esc_html_e('Active','cleanwp-stealth'); ?></div></div><div class="cleanwp-status-list"><?php foreach($status as $item): ?><div class="cleanwp-status-row"><div class="cleanwp-status-icon <?php echo $item[1]?'is-on':'is-off'; ?>"><?php echo $item[1]?'✓':'–'; ?></div><div class="cleanwp-status-copy"><strong><?php echo esc_html($item[0]); ?></strong><span><?php echo esc_html($item[2]); ?></span></div><div class="cleanwp-status-state"><?php echo $item[1]?esc_html__('Enabled','cleanwp-stealth'):esc_html__('Disabled','cleanwp-stealth'); ?></div></div><?php endforeach; ?></div></div>
 <form method="post" action="options.php"><?php settings_fields('cleanwp_stealth_group'); ?><div class="cleanwp-card"><div class="cleanwp-card-head"><div><h2><?php esc_html_e('Stealth Controls','cleanwp-stealth'); ?></h2><p><?php esc_html_e('Choose which common public-facing fingerprints you want to reduce.','cleanwp-stealth'); ?></p></div></div><div class="cleanwp-settings"><?php foreach($settings as $key=>$setting): ?><div class="cleanwp-setting"><div><h3><?php echo esc_html($setting[0]); ?></h3><p><?php echo esc_html($setting[1]); ?></p></div><label class="cleanwp-switch"><input type="checkbox" name="<?php echo esc_attr(self::OPTION.'['.$key.']'); ?>" value="1" <?php checked($o[$key],1); ?>><span></span></label></div><?php endforeach; ?></div></div>
 <div class="cleanwp-card"><div class="cleanwp-card-head"><div><h2><?php esc_html_e('Custom Login URL','cleanwp-stealth'); ?></h2><p><?php esc_html_e('Use a custom path for the WordPress login screen without modifying WordPress core.','cleanwp-stealth'); ?></p></div></div><div class="cleanwp-login-box"><div class="cleanwp-setting"><div><h3><?php esc_html_e('Enable custom login URL','cleanwp-stealth'); ?></h3><p><?php esc_html_e('Bookmark your custom login URL before signing out.','cleanwp-stealth'); ?></p></div><label class="cleanwp-switch"><input type="checkbox" name="<?php echo esc_attr(self::OPTION.'[hide_login]'); ?>" value="1" <?php checked($o['hide_login'],1); ?>><span></span></label></div><div class="cleanwp-field"><label for="cleanwp-login-slug"><?php esc_html_e('Login path','cleanwp-stealth'); ?></label><div class="cleanwp-input-prefix"><span><?php echo esc_html(untrailingslashit(home_url()).'/'); ?></span><input id="cleanwp-login-slug" type="text" name="<?php echo esc_attr(self::OPTION.'[login_slug]'); ?>" value="<?php echo esc_attr($o['login_slug']); ?>" pattern="[A-Za-z0-9_-]+" autocomplete="off"><span>/</span></div><p class="description"><?php esc_html_e('Use letters, numbers, hyphens or underscores. Avoid reserved WordPress paths.','cleanwp-stealth'); ?></p></div><div class="cleanwp-setting"><div><h3><?php esc_html_e('Redirect direct wp-login.php requests','cleanwp-stealth'); ?></h3><p><?php esc_html_e('Optional. Redirect direct requests to your custom login URL.','cleanwp-stealth'); ?></p></div><label class="cleanwp-switch"><input type="checkbox" name="<?php echo esc_attr(self::OPTION.'[redirect_wp_login]'); ?>" value="1" <?php checked($o['redirect_wp_login'],1); ?>><span></span></label></div><?php if(!empty($o['hide_login'])): ?><div class="cleanwp-login-url"><div><span><?php esc_html_e('Current login URL','cleanwp-stealth'); ?></span><strong><?php echo esc_html(self::login_url()); ?></strong></div><a class="button" href="<?php echo esc_url(self::login_url()); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Open Login','cleanwp-stealth'); ?></a></div><?php endif; ?></div></div><div class="cleanwp-actions"><?php submit_button(__('Save CleanWP Settings','cleanwp-stealth'),'primary','submit',false); ?></div></form></div>
 <aside class="cleanwp-side"><div class="cleanwp-card cleanwp-about"><div class="cleanwp-about-logo">S</div><p class="cleanwp-kicker">CREATED BY</p><h2>Sudeep S</h2><p><?php esc_html_e('Founder & CEO, Sangamam Communications Pvt Ltd','cleanwp-stealth'); ?></p><a href="https://www.sudeep.co.in/" target="_blank" rel="noopener noreferrer">www.sudeep.co.in</a><a href="https://www.sangamam.co.in/" target="_blank" rel="noopener noreferrer">www.sangamam.co.in</a></div><div class="cleanwp-card cleanwp-note"><h3><?php esc_html_e('Built for responsible WordPress customization','cleanwp-stealth'); ?></h3><p><?php esc_html_e('CleanWP Stealth does not modify WordPress core. Settings use the WordPress Settings API and public changes use WordPress hooks.','cleanwp-stealth'); ?></p><p><strong><?php esc_html_e('Important:','cleanwp-stealth'); ?></strong> <?php esc_html_e('No plugin can guarantee that WordPress is impossible to identify. This plugin reduces common, obvious fingerprints.','cleanwp-stealth'); ?></p></div><div class="cleanwp-card cleanwp-pro"><span class="cleanwp-pro-label">COMING NEXT</span><h3>CleanWP Stealth Pro</h3><p><?php esc_html_e('Advanced fingerprint auditing, deeper endpoint controls, reports and agency tools are planned for the premium edition.','cleanwp-stealth'); ?></p></div></aside></div><div class="cleanwp-footer"><span>CleanWP Stealth <?php echo esc_html(self::VERSION); ?></span><span>·</span><a href="https://www.sudeep.co.in/" target="_blank" rel="noopener noreferrer">Sudeep S</a><span>·</span><a href="https://www.sangamam.co.in/" target="_blank" rel="noopener noreferrer">Sangamam Communications Pvt Ltd</a></div></div><?php }
}
CleanWP_Stealth::init();
register_activation_hook(__FILE__,function(){update_option(CleanWP_Stealth::OPTION,wp_parse_args((array)get_option(CleanWP_Stealth::OPTION,[]),CleanWP_Stealth::defaults()));CleanWP_Stealth::register_custom_login_rewrite();flush_rewrite_rules();});
register_deactivation_hook(__FILE__,function(){flush_rewrite_rules();});
