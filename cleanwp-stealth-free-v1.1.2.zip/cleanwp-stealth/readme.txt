=== CleanWP Stealth ===
Contributors: sudeep-s
Tags: security, privacy, white label, wordpress, hardening, login
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

CleanWP Stealth reduces common public-facing WordPress fingerprints, protects selected endpoints, and provides an optional custom login URL.

== Description ==

CleanWP Stealth is a lightweight WordPress white-label and fingerprint-control plugin created by Sudeep S / Sangamam Communications Pvt Ltd.

It does not modify WordPress core.

Features:
* Remove the WordPress generator fingerprint.
* Remove common version query strings from enqueued CSS/JS assets.
* Remove selected RSD, WLW, shortlink and REST discovery tags.
* Disable XML-RPC when it is not required.
* Remove public WordPress user REST endpoints.
* Use a custom login URL.
* When custom login is enabled, direct wp-login.php and common logged-out admin/login shorthand URLs are blocked with HTTP 404.
* Logged-in administrators retain normal wp-admin access.
* Optional redirect from direct wp-login.php requests.
* Optional WordPress sitemap disable switch.
* Modern admin settings UI.
* Uses WordPress Settings API and standard sanitization/escaping practices.

== Important ==

No plugin can guarantee that WordPress is impossible to identify. CleanWP Stealth is designed to reduce common, obvious fingerprints.

Before disabling XML-RPC or the WordPress sitemap, make sure your site does not rely on them.

If you enable a custom login URL, bookmark the new URL before logging out.

== Privacy ==

CleanWP Stealth does not send site content, visitor analytics, tracking data, or telemetry to an external service.

The plugin stores its configuration locally in the WordPress options table.

== Credits ==

Developed by Sudeep S.
Sudeep S: https://www.sudeep.co.in/
Sangamam Communications Pvt Ltd: https://www.sangamam.co.in/

== Changelog ==

= 1.1.0 =
* Redesigned admin interface.
* Added branded author/company information.
* Improved custom login URL routing and activation handling.
* Added optional direct wp-login.php redirect.
* Added status overview.
* Added safer settings sanitization and output escaping.
* Added plugin settings shortcut.

= 1.1.2 =
* Strict custom login protection now returns 404 for legacy login/admin endpoints when logged out.
* Prevents /wp-admin/ from being converted into a custom-login redirect while logged out.

= 1.1.1 =
* Improved custom login protection.
* Blocked direct wp-login.php access when custom login is enabled.
* Blocked common logged-out /wp-admin and shorthand login/admin URLs with HTTP 404.
* Preserved wp-admin/admin-ajax.php and wp-admin/admin-post.php compatibility.
